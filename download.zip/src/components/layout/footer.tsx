import Link from 'next/link';
import { Mail, MapPin, Phone, MessageCircle, FileText, Download } from 'lucide-react';
import Logo from './logo';
import { Button } from '../ui/button';
import { Input } from '../ui/input';

const footerNavs = [
  {
    label: 'Company',
    items: [
      { href: '/about', name: 'About' },
      { href: '/blog', name: 'Blog' },
      { href: '/contact', name: 'Contact Us' },
    ],
  },
  {
    label: 'Quick Links',
    items: [
      { href: '/products', name: 'Products' },
      { href: '#', name: 'Services' },
      { href: '#', name: 'Calculators' },
      { href: '/contact', name: 'Get a Quote' },
      { href: '#', name: 'Downloads' },
    ],
  },
  {
    label: 'Legal',
    items: [
      { href: '#', name: 'Privacy Policy' },
      { href: '#', name: 'Terms & Conditions' },
      { href: '#', name: 'Accessibility' },
      { href: '#', name: 'Sitemap' },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="bg-secondary">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4 md:col-span-2 lg:col-span-1">
            <Logo />
            <p className="text-sm text-muted-foreground">
              Evergreen Switchgear is a leading provider of comprehensive electrical solutions, specializing in switchgear, automation, and power management systems for diverse industries.
            </p>
            <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                    <Phone size={16} />
                    <span>Tel: +92 51 4864909</span>
                </div>
                <div className="flex items-center gap-2">
                    <FileText size={16} />
                    <span>Fax: +92 51 4864908</span>
                </div>
                <div className="flex items-center gap-2">
                    <MessageCircle size={16} />
                    <span>WhatsApp: +92 321 9574003</span>
                </div>
                <div className="flex items-center gap-2">
                    <Mail size={16} />
                    <span>admin@egswitchgear.com</span>
                </div>
                <div className="flex items-start gap-2">
                    <MapPin size={16} className="mt-1 flex-shrink-0" />
                    <span>Plot # 56, Street # 13, I-9/2 ,Islamabad, Pakistan</span>
                </div>
            </div>
          </div>
          {footerNavs.map((nav) => (
            <div key={nav.label}>
              <h3 className="font-headline font-semibold text-foreground">{nav.label}</h3>
              <ul className="space-y-2 mt-4">
                {nav.items.map((item) => (
                  <li key={item.name}>
                    <Link
                      href={item.href}
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <div>
            <h3 className="font-headline font-semibold text-foreground">Stay Updated</h3>
            <p className="text-sm text-muted-foreground mt-4">
              Subscribe to our newsletter for the latest product updates and industry news.
            </p>
            <form className="mt-4 flex gap-2">
              <Input type="email" placeholder="your.email@example.com" className="bg-background" />
              <Button type="submit">Subscribe</Button>
            </form>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Evergreen Switchgear. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground">
            Powered by <a href="#" className="hover:text-primary">Agilex Developers</a>.
          </p>
        </div>
      </div>
    </footer>
  );
}
