'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X, ChevronDown } from 'lucide-react';
import { useState } from 'react';

import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetDescription,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { cn } from '@/lib/utils';
import Logo from './logo';
import { ThemeToggle } from '@/components/theme-toggle';
import { calculatorData } from '@/lib/calculators';
import { ScrollArea } from '@/components/ui/scroll-area';

const productCategories = [
  { href: '/products', label: 'Electrical Panels' },
  { href: '/products', label: 'Power Distribution' },
  { href: '/products', label: 'Cable Management Solutions' },
  { href: '/products', label: 'Industrial Automation & Control' },
  { href: '/products', label: 'Lighting & Emergency Systems' },
  { href: '/products', label: 'Security & Safety Solutions' },
  { href: '/products', label: 'Industrial & Telecom Enclosures' },
  { href: '/products', label: 'Storage & Infrastructure Solutions' },
  { href: '/products', label: 'Fabrication & Coating Services' },
  { href: '/products', label: 'Solar Systems' },
];

const calculatorCategories = calculatorData.map(calc => ({
    href: `/calculators/${calc.slug}`,
    label: calc.title,
}));

const navLinks = [
  { href: '/', label: 'Home' },
  {
    href: '/products',
    label: 'Products',
    isMenu: true,
    items: productCategories,
  },
  { href: '/services', label: 'Services' },
  {
    href: '/calculators',
    label: 'Calculators',
    isMenu: true,
    items: calculatorCategories,
  },
  { href: '/about', label: 'About Us' },
  { href: '/certifications', label: 'Certifications' },
  { href: '/blog', label: 'Blog' },
  { href: '/contact', label: 'Contact' },
];

export default function Header() {
  const pathname = usePathname();
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);

  const NavLink = ({
    href,
    label,
    isMobile = false,
  }: {
    href: string;
    label: string;
    isMobile?: boolean;
  }) => {
    const isActive = pathname === href;
    return (
      <Link
        href={href}
        onClick={() => setMobileMenuOpen(false)}
        className={cn(
          'transition-colors hover:text-primary',
          isActive ? 'text-primary font-semibold' : 'text-foreground/60',
          isMobile ? 'text-lg' : 'text-sm font-medium'
        )}
      >
        {label}
      </Link>
    );
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <Logo />
        <nav className="hidden md:flex items-center space-x-6 ml-10">
          {navLinks.map((link) =>
            link.isMenu ? (
              <DropdownMenu key={link.label}>
                <DropdownMenuTrigger asChild>
                   <Button
                    variant="ghost"
                    className={cn(
                      'transition-colors hover:text-primary p-0 h-auto text-sm font-medium focus-visible:ring-0',
                      pathname.startsWith(link.href)
                        ? 'text-primary font-semibold'
                        : 'text-foreground/60'
                    )}
                  >
                    {link.label}
                    <ChevronDown className="relative top-[1px] ml-1 h-3 w-3 transition duration-200 group-data-[state=open]:rotate-180" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  {link.href === '/calculators' && (
                     <DropdownMenuItem asChild>
                      <Link href="/calculators">All Calculators</Link>
                    </DropdownMenuItem>
                  )}
                  {link.items?.map((item) => (
                    <DropdownMenuItem key={item.label} asChild>
                      <Link href={item.href}>{item.label}</Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <NavLink key={link.href} href={link.href} label={link.label} />
            )
          )}
        </nav>
        <div className="flex flex-1 items-center justify-end space-x-2">
          <ThemeToggle />
          <Button asChild variant="outline">
            <Link href="/admin">Admin Portal</Link>
          </Button>

          {/* Mobile Menu */}
          <Sheet open={isMobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Open menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full flex flex-col">
               <SheetHeader className="p-0 text-left">
                <SheetTitle className="sr-only">Mobile Menu</SheetTitle>
                <SheetDescription className="sr-only">Main navigation menu for mobile devices.</SheetDescription>
                 <div className="flex justify-between items-center">
                  <Logo />
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <X className="h-6 w-6" />
                      <span className="sr-only">Close menu</span>
                    </Button>
                  </SheetTrigger>
                </div>
               </SheetHeader>
               <ScrollArea className="flex-1 -mx-6">
                <nav className="flex flex-col space-y-2 px-6 py-4">
                  {navLinks.map((link) =>
                    link.isMenu ? (
                      <Collapsible key={link.label}>
                        <CollapsibleTrigger className="flex justify-between items-center w-full text-lg font-medium py-2">
                          <Link href={link.href} onClick={() => setMobileMenuOpen(false)}>{link.label}</Link>
                          <ChevronDown className="h-4 w-4" />
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="pl-4 flex flex-col space-y-2">
                            {link.href === '/calculators' && (
                              <Link
                                href="/calculators"
                                onClick={() => setMobileMenuOpen(false)}
                                className="text-muted-foreground hover:text-primary"
                              >
                                All Calculators
                              </Link>
                            )}
                            {link.items?.map((item) => (
                              <Link
                                key={item.label}
                                href={item.href}
                                onClick={() => setMobileMenuOpen(false)}
                                className="text-muted-foreground hover:text-primary"
                              >
                                {item.label}
                              </Link>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    ) : (
                      <NavLink
                        key={link.href}
                        href={link.href}
                        label={link.label}
                        isMobile
                      />
                    )
                  )}
                </nav>
              </ScrollArea>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
