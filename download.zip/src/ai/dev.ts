import { config } from 'dotenv';
config();

import '@/ai/flows/generate-about-us.ts';