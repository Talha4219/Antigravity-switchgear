'use server';

/**
 * @fileOverview This file defines a Genkit flow for generating engaging "About Us" content.
 *
 * The flow uses a prompt to create informative content highlighting the company's expertise,
 * history, and core values. It exports a function, generateAboutUsContent, that
 * takes company details as input and returns the generated content.
 *
 * @exports generateAboutUsContent - A function to generate "About Us" content.
 * @exports GenerateAboutUsInput - The input type for the generateAboutUsContent function.
 * @exports GenerateAboutUsOutput - The output type for the generateAboutUsContent function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Define the input schema
const GenerateAboutUsInputSchema = z.object({
  companyName: z.string().describe('The name of the company.'),
  companyMission: z.string().describe('The mission statement of the company.'),
  companyHistory: z.string().describe('A brief history of the company.'),
  companyValues: z.string().describe('The core values of the company.'),
  companyExpertise: z.string().describe('Description of the company expertise.'),
});
export type GenerateAboutUsInput = z.infer<typeof GenerateAboutUsInputSchema>;

// Define the output schema
const GenerateAboutUsOutputSchema = z.object({
  aboutUsContent: z.string().describe('The generated content for the About Us section.'),
});
export type GenerateAboutUsOutput = z.infer<typeof GenerateAboutUsOutputSchema>;

// Define the prompt
const generateAboutUsPrompt = ai.definePrompt({
  name: 'generateAboutUsPrompt',
  input: {schema: GenerateAboutUsInputSchema},
  output: {schema: GenerateAboutUsOutputSchema},
  prompt: `You are an expert copywriter specializing in creating engaging and informative "About Us" content for B2B websites.

  Using the following information about the company, create compelling content for the "About Us" section of their website.

  Company Name: {{{companyName}}}
  Company Mission: {{{companyMission}}}
  Company History: {{{companyHistory}}}
  Company Values: {{{companyValues}}}
  Company Expertise: {{{companyExpertise}}}

  The content should be written in a professional and engaging tone, highlighting the company's expertise, history, and core values.
  Focus on building trust and credibility with potential customers.
  The content should be well-structured and easy to read.
  Include a call to action encouraging visitors to learn more about the company's products and services.
  Make sure to inject industry-relevant keywords and phrases where appropriate, for SEO optimization purposes.
  Always prioritize quality, clarity, and accuracy.
  Limit the number of words to under 500. Do not exceed this limit.
  `,
});

// Define the flow
const generateAboutUsFlow = ai.defineFlow(
  {
    name: 'generateAboutUsFlow',
    inputSchema: GenerateAboutUsInputSchema,
    outputSchema: GenerateAboutUsOutputSchema,
  },
  async input => {
    const {output} = await generateAboutUsPrompt(input);
    return output!;
  }
);

/**
 * Generates engaging "About Us" content using the provided company information.
 * @param input - The input data containing company details.
 * @returns A promise that resolves to the generated "About Us" content.
 */
export async function generateAboutUsContent(input: GenerateAboutUsInput): Promise<GenerateAboutUsOutput> {
  return generateAboutUsFlow(input);
}
