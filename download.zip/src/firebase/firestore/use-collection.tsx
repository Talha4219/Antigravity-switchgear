'use client';
import {
  collection,
  onSnapshot,
  query,
  where,
  type CollectionReference,
  type Query,
} from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { useFirestore } from '../provider';

type Options = {
  disabled?: boolean;
};

export function useCollection<T>(
  collectionOrQuery: CollectionReference | Query | null,
  options: Options = {
    disabled: false,
  }
) {
  const [data, setData] = useState<T[] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!collectionOrQuery || options.disabled) {
      setData(null);
      setLoading(false);
      return;
    }

    setLoading(true);

    const unsubscribe = onSnapshot(collectionOrQuery, (snapshot) => {
      const data: T[] = [];
      snapshot.forEach((doc) => {
        data.push({ ...doc.data(), id: doc.id } as T);
      });
      setData(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [collectionOrQuery, options.disabled]);

  return { data, loading };
}
