'use client';

import { FirebaseApp } from 'firebase/app';
import { Auth } from 'firebase/auth';
import { Firestore } from 'firebase/firestore';
import { ReactNode } from 'react';
import { FirebaseProvider } from './provider';
import { initializeFirebase } from '.';

type FirebaseClientProviderProps = {
  children: ReactNode;
};

let app: FirebaseApp;
let auth: Auth;
let firestore: Firestore;

export function FirebaseClientProvider({
  children,
}: FirebaseClientProviderProps) {
  if (!app) {
    const firebase = initializeFirebase();
    app = firebase.app;
    auth = firebase.auth;
    firestore = firebase.firestore;
  }
  return (
    <FirebaseProvider app={app} auth={auth} firestore={firestore}>
      {children}
    </FirebaseProvider>
  );
}
