import React from 'react';
import { Zap, TrendingDown, Server, Network, Gauge, Ruler, LayoutPanelLeft, Sun, Clock, SunMedium, Battery } from "lucide-react";
import FaultCurrentCalculator from "@/app/calculators/components/fault-current-calculator";
import VoltageDropCalculator from "@/app/calculators/components/voltage-drop-calculator";
import LoadCalculator from "@/app/calculators/components/load-calculator";
import TransformerSizingCalculator from "@/app/calculators/components/transformer-sizing-calculator";
import PowerFactorCorrectionCalculator from "@/app/calculators/components/power-factor-correction-calculator";
import CableSizeCalculator from "@/app/calculators/components/cable-size-calculator";
import CableTrayFillCalculator from "@/app/calculators/components/cable-tray-fill-calculator";
import IlluminanceCalculator from "@/app/calculators/components/illuminance-calculator";
import EmergencyLightingRunTimeCalculator from "@/app/calculators/components/emergency-lighting-calculator";
import SolarPanelOutputCalculator from "@/app/calculators/components/solar-panel-output-calculator";
import SolarBatterySizingCalculator from "@/app/calculators/components/solar-battery-sizing-calculator";

export type CalculatorInfo = {
    slug: string;
    title: string;
    description: React.ReactNode;
    icon: React.ElementType;
    formula: React.ReactNode;
    component: React.ElementType;
};

export const calculatorData: CalculatorInfo[] = [
    {
        slug: 'fault-current',
        title: 'Fault Current Calculator',
        description: <p>Calculates the symmetrical short-circuit fault current in a three-phase system based on the transformer's kVA rating, voltage, and impedance. This is crucial for selecting appropriately rated protective devices.</p>,
        icon: Zap,
        formula: <code>I_fault = (kVA * 1000) / (V * sqrt(3)) / (Z / 100)</code>,
        component: FaultCurrentCalculator,
    },
    {
        slug: 'voltage-drop',
        title: 'Voltage Drop Calculator',
        description: <p>Determines the voltage drop across a length of cable. This ensures that the voltage at the load remains within acceptable limits for proper equipment operation.</p>,
        icon: TrendingDown,
        formula: <code>VD = (Multiplier * K * I * L) / CM</code>,
        component: VoltageDropCalculator,
    },
    {
        slug: 'load-calculator',
        title: 'Load Calculator',
        description: <p>Estimates the total electrical load and required current for a system by summing up individual loads. This is a fundamental step in designing and sizing an electrical system.</p>,
        icon: Server,
        formula: <code>Total Amps = Total VA / (V * Phase_Multiplier)</code>,
        component: LoadCalculator,
    },
    {
        slug: 'transformer-sizing',
        title: 'Transformer Sizing Calculator',
        description: <p>Helps determine the appropriate kVA size for a transformer based on the total load, voltage, and considerations for future expansion.</p>,
        icon: Network,
        formula: <code>kVA = (Load Amps * V * Phase_Multiplier) / 1000</code>,
        component: TransformerSizingCalculator,
    },
    {
        slug: 'power-factor-correction',
        title: 'Power Factor Correction Calculator',
        description: <p>Calculates the required reactive power (kVAR) from a capacitor bank needed to improve a system's power factor from a current level to a target level.</p>,
        icon: Gauge,
        formula: <code>kVAR = kW * (tan(acos(PF_current)) - tan(acos(PF_target)))</code>,
        component: PowerFactorCorrectionCalculator,
    },
    {
        slug: 'cable-size-calculator',
        title: 'Cable Size Calculator',
        description: <p>Estimates the required electrical cable size (in AWG) based on the load current, distance, and acceptable voltage drop, which is essential for safety and efficiency.</p>,
        icon: Ruler,
        formula: <code>CM = (Multiplier * K * I * L) / Max_VD</code>,
        component: CableSizeCalculator,
    },
    {
        slug: 'cable-tray-fill',
        title: 'Cable Tray Fill Calculator',
        description: <p>Calculates the percentage of a cable tray's cross-sectional area that is occupied by cables, ensuring compliance with NEC (National Electrical Code) fill requirements.</p>,
        icon: LayoutPanelLeft,
        formula: <code>Fill % = (Total Cable Area / Max Fill Area) * 100</code>,
        component: CableTrayFillCalculator,
    },
    {
        slug: 'illuminance-calculator',
        title: 'Illuminance Calculator',
        description: <p>Estimates the average illuminance level (in lux or foot-candles) for a space, based on the total lumens of light sources, the area, and factors for utilization and light loss.</p>,
        icon: Sun,
        formula: <code>E = (Lumens * CU * LLF) / Area</code>,
        component: IlluminanceCalculator,
    },
    {
        slug: 'emergency-lighting-run-time',
        title: 'Emergency Lighting Run Time',
        description: <p>Calculates how long an emergency lighting system can operate on its battery backup, based on battery capacity, voltage, and the total power draw of the lights.</p>,
        icon: Clock,
        formula: <code>Run Time = (Ah * V) / (Load / Efficiency)</code>,
        component: EmergencyLightingRunTimeCalculator,
    },
    {
        slug: 'solar-panel-output',
        title: 'Solar Panel Output Calculator',
        description: <p>Estimates the expected energy output (in kWh) of a solar panel system based on panel ratings, the number of panels, peak sun hours, and system efficiency.</p>,
        icon: SunMedium,
        formula: <code>Energy = Total kW * Sun Hours * Perf. Ratio</code>,
        component: SolarPanelOutputCalculator,
    },
    {
        slug: 'solar-battery-sizing',
        title: 'Solar Battery Sizing Calculator',
        description: <p>Determines the required battery bank capacity (in kWh and Ah) for an off-grid or backup solar power system, considering daily energy use and desired autonomy.</p>,
        icon: Battery,
        formula: <code>kWh = (Daily Use * Autonomy) / DoD</code>,
        component: SolarBatterySizingCalculator,
    },
]
