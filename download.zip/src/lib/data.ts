import { collection, getDocs, getFirestore } from 'firebase/firestore';

export type Product = {
  id: string;
  name: string;
  description: string;
  specs: string;
  applications: string[];
  imageId: string;
};

export type BlogPost = {
  id:string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
  imageId: string;
  status: 'Published' | 'Draft';
};

export type Offer = {
  id: string;
  title: string;
  description: string;
  discount: string;
  validUntil: string;
};

export type Certification = {
  id: string;
  name: string;
  issuingBody: string;
  description: string;
  imageId: string;
};

const products: Product[] = [
  {
    id: '1',
    name: 'Low Voltage Switchgear SG-LV100',
    description: 'Compact and reliable low voltage switchgear for commercial and light industrial applications. Ensures safety and optimal power distribution.',
    specs: 'Up to 690V, 6300A, 120kA',
    applications: ['Commercial Buildings', 'Data Centers', 'Hospitals', 'Light Industry'],
    imageId: 'product-lv-switchgear',
  },
  {
    id: '2',
    name: 'Medium Voltage Switchgear SG-MV500',
    description: 'Air-insulated medium voltage switchgear designed for primary distribution networks. Features high reliability and easy maintenance.',
    specs: 'Up to 36kV, 4000A, 50kA',
    applications: ['Utility Substations', 'Manufacturing Plants', 'Renewable Energy', 'Infrastructure'],
    imageId: 'product-mv-switchgear',
  },
  {
    id: '3',
    name: 'High Voltage GIS SG-HV900',
    description: 'Gas-insulated high voltage switchgear for transmission networks where space is a constraint. Offers excellent performance and a long service life.',
    specs: 'Up to 550kV, 5000A, 63kA',
    applications: ['Power Plants', 'Urban Substations', 'Heavy Industry', 'Grid Interconnections'],
    imageId: 'product-hv-switchgear',
  },
  {
    id: '4',
    name: 'Molded Case Circuit Breaker (MCCB)',
    description: 'Provides superior overload and short-circuit protection for a wide range of applications. Available in various frame sizes and trip units.',
    specs: 'Up to 1600A',
    applications: ['Panelboards', 'Switchboards', 'Motor Control Centers', 'Individual Enclosures'],
    imageId: 'product-cb',
  },
  {
    id: '5',
    name: 'Digital Protective Relay PR-D20',
    description: 'Advanced multifunctional relay for protection, control, and monitoring of feeders, motors, and transformers. Features extensive communication options.',
    specs: 'IEC 61850 Compliant',
    applications: ['Feeder Protection', 'Motor Protection', 'Transformer Protection', 'Bay Control'],
    imageId: 'product-relay',
  },
  {
    id: '6',
    name: 'Control Power Transformer CPT-300',
    description: 'High-quality control power transformer providing stepped-down voltages to power control circuits. Designed for industrial environments.',
    specs: '50VA to 5kVA',
    applications: ['Switchgear Panels', 'Control Cabinets', 'Industrial Machinery', 'Automation Systems'],
    imageId: 'product-transformer',
  },
];

const blogPosts: BlogPost[] = [
  {
    id: '1',
    slug: 'the-future-of-smart-switchgear',
    title: 'The Future of Smart Switchgear: IoT and AI Integration',
    excerpt: 'Explore how the Internet of Things (IoT) and Artificial Intelligence (AI) are revolutionizing switchgear technology, leading to predictive maintenance, enhanced safety, and improved energy efficiency in modern power grids.',
    content: 'The integration of IoT and AI into switchgear systems marks a significant leap forward in power distribution technology. Smart switchgear can now monitor its own health, predict potential failures, and optimize energy flow in real-time. This not only increases reliability and safety but also provides valuable data for grid management. In this post, we delve into the key technologies, benefits, and future trends of intelligent switchgear systems.',
    date: 'July 15, 2024',
    author: 'Jane Doe, Lead Engineer',
    imageId: 'blog-1',
    status: 'Published',
  },
  {
    id: '2',
    slug: 'arc-flash-safety-innovations',
    title: 'Innovations in Arc Flash Safety: Protecting Personnel and Assets',
    excerpt: 'Arc flash incidents are a major concern in the electrical industry. This post covers the latest advancements in arc flash detection and mitigation technologies that are making workplaces safer.',
    content: 'Ensuring personnel safety is paramount. New technologies, such as faster-acting relays, optical sensors, and remote racking systems, are drastically reducing the risks associated with arc flash events. We discuss the importance of a comprehensive safety strategy, including risk assessment, proper PPE, and the adoption of modern, safer switchgear designs.',
    date: 'June 28, 2024',
    author: 'John Smith, Safety Officer',
    imageId: 'blog-2',
    status: 'Published',
  },
    {
    id: '3',
    slug: 'iec-61850-standard-explained',
    title: 'Understanding the IEC 61850 Standard',
    excerpt: 'A deep dive into the IEC 61850 standard for communication in substations. Learn why it\'s crucial for modern automation and interoperability.',
    content: 'IEC 61850 is more than just a protocol; it\'s a comprehensive standard that defines the communication architecture for substation automation. This article explains its key components, such as the data models and communication services, and highlights the benefits of adopting this standard, including improved interoperability, reduced engineering costs, and future-proof designs.',
    date: 'May 10, 2024',
    author: 'Dr. Emily Carter',
    imageId: 'blog-3',
    status: 'Draft',
  },
];

const specialOffers: Offer[] = [
  {
    id: '1',
    title: 'Q3 Volume Discount',
    description: 'Get a 15% discount on all orders of Low Voltage Switchgear exceeding $50,000.',
    discount: '15% OFF',
    validUntil: 'September 30, 2024',
  },
  {
    id: '2',
    title: 'Free Training Session',
    description: 'Receive a complimentary on-site safety training session with any Medium Voltage product purchase.',
    discount: 'FREE TRAINING',
    validUntil: 'December 31, 2024',
  },
];

const certifications: Certification[] = [
  {
    id: '1',
    name: 'ISO 9001:2015',
    issuingBody: 'International Organization for Standardization',
    description: 'Demonstrates our commitment to quality management systems and continuous improvement to meet customer and regulatory requirements.',
    imageId: 'cert-iso9001',
  },
  {
    id: '2',
    name: 'ISO 14001:2015',
    issuingBody: 'International Organization for Standardization',
    description: 'Certifies our effective environmental management system, ensuring we minimize our environmental impact and operate sustainably.',
    imageId: 'cert-iso14001',
  },
  {
    id: '3',
    name: 'IEC 62271 Compliance',
    issuingBody: 'International Electrotechnical Commission',
    description: 'Our products are designed and tested in accordance with the rigorous international standards for high-voltage switchgear and controlgear.',
    imageId: 'cert-iec',
  },
  {
    id: '4',
    name: 'UL Listed',
    issuingBody: 'Underwriters Laboratories',
    description: 'Select products are UL Listed, meeting North American safety and performance standards for electrical equipment.',
    imageId: 'cert-ul',
  },
  {
    id: '5',
    name: 'CE Marking',
    issuingBody: 'European Economic Area',
    description: 'Our products conform with the health, safety, and environmental protection standards for products sold within the European Economic Area.',
    imageId: 'cert-ce',
  },
   {
    id: '6',
    name: 'RoHS Compliant',
    issuingBody: 'Restriction of Hazardous Substances Directive',
    description: 'We adhere to the RoHS directive, restricting the use of specific hazardous materials found in electrical and electronic products.',
    imageId: 'cert-rohs',
  },
];

// Functions to get data from static arrays
export const getProducts = () => products;
export const getFeaturedProducts = () => products.slice(0, 3);
export const getProductById = (id: string) => products.find(p => p.id === id);

export const getBlogPosts = () => blogPosts;
export const getRecentPosts = () => blogPosts.filter(p => p.status === 'Published').slice(0, 2);
export const getPostBySlug = (slug: string) => blogPosts.find(p => p.slug === slug);

export const getSpecialOffers = () => specialOffers;

export const getCertifications = () => certifications;

// Functions to seed data into Firestore (call these once)
export const seedData = async () => {
  const db = getFirestore();
  
  const seedCollection = async (collectionName: string, data: any[]) => {
    const collRef = collection(db, collectionName);
    const snapshot = await getDocs(collRef);
    if (snapshot.empty) {
      console.log(`Seeding ${collectionName}...`);
      const { setDoc, doc } = await import('firebase/firestore');
      for (const item of data) {
        // Use a specific ID if available, otherwise let Firestore generate one
        const docRef = item.id ? doc(db, collectionName, item.id) : doc(collRef);
        await setDoc(docRef, item);
      }
      console.log(`${collectionName} seeded.`);
    } else {
      console.log(`${collectionName} already contains data. Skipping seed.`);
    }
  };

  try {
    await seedCollection('products', products);
    await seedCollection('blogPosts', blogPosts);
    await seedCollection('specialOffers', specialOffers);
    await seedCollection('certifications', certifications);
  } catch (error) {
    console.error("Error seeding data: ", error);
  }
};
