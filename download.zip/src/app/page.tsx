import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight, Building, Cog, FileText, Newspaper, ShieldCheck, Tag, Zap } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';
import { getFeaturedProducts, getRecentPosts, getSpecialOffers, getCertifications } from '@/lib/data';
import { placeholderImages } from '@/lib/placeholder-images';

export default function Home() {
  const featuredProducts = getFeaturedProducts();
  const recentPosts = getRecentPosts();
  const specialOffers = getSpecialOffers();
  const certifications = getCertifications().slice(0, 4);
  const heroImage = placeholderImages.find(p => p.id === 'hero');

  return (
    <div className="flex flex-col min-h-dvh">
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative h-[60vh] md:h-[70vh] w-full flex items-center justify-center text-center text-white bg-primary">
          {heroImage && (
            <Image
              src={heroImage.imageUrl}
              alt={heroImage.description}
              fill
              className="object-cover opacity-20"
              priority
              data-ai-hint={heroImage.imageHint}
            />
          )}
          <div className="relative z-10 p-4 max-w-4xl text-primary-foreground">
            <h1 className="text-4xl md:text-6xl font-headline font-bold tracking-tight">
              Engineering the Future of Power Distribution
            </h1>
            <p className="mt-4 text-lg md:text-xl text-primary-foreground/80 max-w-2xl mx-auto">
              SwitchGear Pro delivers robust and reliable switchgear solutions,
              customized for the most demanding industrial applications.
            </p>
            <div className="mt-8 flex justify-center gap-4">
              <Button asChild size="lg" className="bg-primary-foreground text-primary hover:bg-primary-foreground/90">
                <Link href="/products">Explore Products</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10">
                <Link href="/contact">Contact Sales</Link>
              </Button>
            </div>
          </div>
        </section>

        <div className="bg-background">
          {/* Featured Products Section */}
          <section id="products" className="py-16 md:py-24">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <Cog className="mx-auto h-12 w-12 text-primary" />
                <h2 className="mt-4 text-3xl md:text-4xl font-headline font-semibold">
                  Our Products
                </h2>
                <p className="mt-2 text-lg text-muted-foreground max-w-2xl mx-auto">
                  Discover our range of high-performance switchgear, built for safety and efficiency.
                </p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {featuredProducts.map((product) => {
                  const productImage = placeholderImages.find(p => p.id === product.imageId);
                  return (
                    <Card key={product.id} className="flex flex-col overflow-hidden hover:shadow-lg transition-shadow duration-300">
                      <CardHeader className="p-0">
                        {productImage && (
                          <Image
                            src={productImage.imageUrl}
                            alt={product.name}
                            width={600}
                            height={400}
                            className="w-full h-48 object-cover"
                            data-ai-hint={productImage.imageHint}
                          />
                        )}
                      </CardHeader>
                      <CardContent className="flex-grow pt-6">
                        <h3 className="text-xl font-bold font-headline">{product.name}</h3>
                        <div className="flex items-center gap-2 mt-2">
                           <Zap className="h-4 w-4 text-accent" />
                           <p className="text-sm text-muted-foreground">{product.specs}</p>
                        </div>
                        <p className="mt-4 text-sm text-foreground/80">{product.description}</p>
                      </CardContent>
                      <CardFooter>
                        <Button asChild variant="outline" className="w-full">
                          <Link href="/products">View Details <ArrowRight className="ml-2 h-4 w-4" /></Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
              <div className="text-center mt-12">
                <Button asChild size="lg">
                  <Link href="/products">See Full Catalog</Link>
                </Button>
              </div>
            </div>
          </section>

          {/* About Us Snippet */}
          <section className="bg-secondary py-16 md:py-24">
            <div className="container mx-auto px-4 text-center">
              <Building className="mx-auto h-12 w-12 text-primary" />
              <h2 className="mt-4 text-3xl md:text-4xl font-headline font-semibold">
                Decades of Expertise
              </h2>
              <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
                With a rich history of innovation, SwitchGear Pro has been a trusted partner in the energy sector, committed to quality, safety, and customer satisfaction. Our core values drive us to engineer superior solutions that power industries worldwide.
              </p>
              <Button asChild size="lg" variant="link" className="mt-6 text-lg">
                <Link href="/about">Learn more about us <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
            </div>
          </section>

          {/* Latest Updates Section */}
          <section className="py-16 md:py-24">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <Newspaper className="mx-auto h-12 w-12 text-primary" />
                <h2 className="mt-4 text-3xl md:text-4xl font-headline font-semibold">Latest Updates</h2>
                <p className="mt-2 text-lg text-muted-foreground max-w-2xl mx-auto">
                  Stay informed with our latest articles, news, and industry insights.
                </p>
              </div>
              <div className="grid md:grid-cols-2 gap-8">
                {recentPosts.map((post) => {
                  const postImage = placeholderImages.find(p => p.id === post.imageId);
                  return (
                    <Link href={`/blog/${post.slug}`} key={post.id} className="group">
                      <Card className="overflow-hidden h-full flex flex-col">
                        <CardHeader className="p-0">
                           {postImage && (
                            <Image src={postImage.imageUrl} alt={post.title} width={600} height={400} className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300" data-ai-hint={postImage.imageHint} />
                          )}
                        </CardHeader>
                        <CardContent className="pt-6 flex-grow">
                           <p className="text-sm text-muted-foreground">{post.date}</p>
                           <h3 className="mt-1 text-xl font-bold font-headline group-hover:text-primary transition-colors">{post.title}</h3>
                          <p className="mt-2 text-sm text-foreground/80 line-clamp-3">{post.excerpt}</p>
                        </CardContent>
                         <CardFooter>
                           <span className="text-sm font-semibold text-primary group-hover:underline">Read More <ArrowRight className="inline-block ml-1 h-4 w-4" /></span>
                        </CardFooter>
                      </Card>
                    </Link>
                  )
                })}
              </div>
            </div>
          </section>

          {/* Certifications Section */}
          <section id="certifications" className="bg-secondary py-16 md:py-24">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <ShieldCheck className="mx-auto h-12 w-12 text-primary" />
                <h2 className="mt-4 text-3xl md:text-4xl font-headline font-semibold">
                  Certified Quality &amp; Compliance
                </h2>
                <p className="mt-2 text-lg text-muted-foreground max-w-2xl mx-auto">
                  Our commitment to excellence is backed by internationally recognized certifications.
                </p>
              </div>
              <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
                {certifications.map((cert) => {
                  const certImage = placeholderImages.find(p => p.id === cert.imageId);
                  return (
                    certImage && <Image
                      key={cert.id}
                      src={certImage.imageUrl}
                      alt={cert.name}
                      width={120}
                      height={120}
                      className="object-contain grayscale hover:grayscale-0 transition-all duration-300"
                      title={cert.name}
                      data-ai-hint={certImage.imageHint}
                    />
                  )
                })}
              </div>
               <div className="text-center mt-12">
                <Button asChild size="lg" variant="outline">
                  <Link href="/certifications">View All Certifications</Link>
                </Button>
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
