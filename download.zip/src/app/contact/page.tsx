'use client'

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail, MapPin, Phone, Building } from "lucide-react"
import Image from "next/image"
import { placeholderImages } from "@/lib/placeholder-images"
import Link from "next/link"


const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  email: z.string().email({
    message: "Please enter a valid email address.",
  }),
  company: z.string().optional(),
  subject: z.string().min(5, {
    message: "Subject must be at least 5 characters.",
  }),
  message: z.string().min(10, {
    message: "Message must be at least 10 characters.",
  }),
})

export default function ContactPage() {
    const { toast } = useToast();
    const mapImage = placeholderImages.find(p => p.id === 'contact-map');

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      company: "",
      subject: "",
      message: "",
    },
  })
 
  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values)
    toast({
      title: "Message Sent!",
      description: "Thank you for contacting us. We will get back to you shortly.",
    })
    form.reset()
  }

  return (
    <>
      <section className="bg-primary text-primary-foreground">
        <div className="container py-16 text-center">
          <h1 className="text-4xl md:text-5xl font-headline font-bold">Contact Us</h1>
          <p className="mt-4 text-lg md:text-xl text-primary-foreground/80 max-w-3xl mx-auto">
            We're here to help. Reach out to our team for sales inquiries, technical support, or any other questions.
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid lg:grid-cols-3 gap-8 md:gap-12">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="font-headline text-2xl">Send us a Message</CardTitle>
                  <CardDescription>Fill out the form below and our team will respond within 24 hours.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <div className="grid sm:grid-cols-2 gap-6">
                            <FormField
                                control={form.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Full Name</FormLabel>
                                    <FormControl>
                                        <Input placeholder="John Doe" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={form.control}
                                name="email"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>Email Address</FormLabel>
                                    <FormControl>
                                        <Input placeholder="john.doe@example.com" {...field} />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                        </div>
                        <FormField
                            control={form.control}
                            name="subject"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Subject</FormLabel>
                                <FormControl>
                                    <Input placeholder="e.g., Quote for MV Switchgear" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Message</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Please describe your inquiry in detail..." className="min-h-[150px]" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" size="lg" className="w-full">Submit Inquiry</Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-8">
              <Card>
                  <CardHeader>
                      <CardTitle className="font-headline">Contact Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4 text-sm">
                    <div className="flex items-start gap-3">
                        <Phone className="h-5 w-5 mt-1 text-primary flex-shrink-0" />
                        <div>
                            <h4 className="font-semibold">Sales &amp; Support</h4>
                            <p className="text-muted-foreground">+1 (555) 123-4567</p>
                        </div>
                    </div>
                     <div className="flex items-start gap-3">
                        <Mail className="h-5 w-5 mt-1 text-primary flex-shrink-0" />
                        <div>
                            <h4 className="font-semibold">Email</h4>
                            <p className="text-muted-foreground">sales@switchgearpro.com</p>
                        </div>
                    </div>
                     <div className="flex items-start gap-3">
                        <Building className="h-5 w-5 mt-1 text-primary flex-shrink-0" />
                        <div>
                            <h4 className="font-semibold">Headquarters</h4>
                            <p className="text-muted-foreground">123 Industrial Way<br/>Electra City, 54321</p>
                        </div>
                    </div>
                  </CardContent>
              </Card>
              <Card className="overflow-hidden">
                <CardHeader>
                    <CardTitle className="font-headline">Our Location</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                    {mapImage && 
                        <Link href="https://maps.google.com" target="_blank">
                            <Image src={mapImage.imageUrl} alt={mapImage.description} width={800} height={600} className="w-full h-auto" data-ai-hint={mapImage.imageHint}/>
                        </Link>
                    }
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
