import Image from 'next/image';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Check, Cog, Zap } from 'lucide-react';
import { getProducts } from '@/lib/data';
import { placeholderImages } from '@/lib/placeholder-images';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export const metadata = {
  title: 'Our Products | SwitchGear Pro',
  description: 'Explore our comprehensive catalog of low, medium, and high voltage switchgear, circuit breakers, and protective relays.',
};

export default function ProductsPage() {
  const products = getProducts();

  return (
    <>
      <section className="bg-primary text-primary-foreground">
        <div className="container py-16 text-center">
          <h1 className="text-4xl md:text-5xl font-headline font-bold">Product Catalog</h1>
          <p className="mt-4 text-lg md:text-xl text-primary-foreground/80 max-w-3xl mx-auto">
            Engineered for reliability and performance, our switchgear solutions meet the highest industry standards.
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => {
              const productImage = placeholderImages.find((p) => p.id === product.imageId);
              return (
                <Card key={product.id} className="flex flex-col overflow-hidden group">
                   <CardHeader className="p-0 border-b">
                    {productImage && (
                      <div className="overflow-hidden">
                        <Image
                          src={productImage.imageUrl}
                          alt={product.name}
                          width={600}
                          height={400}
                          className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-300"
                          data-ai-hint={productImage.imageHint}
                        />
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="flex-grow pt-6 space-y-4">
                    <div>
                      <h2 className="text-xl font-headline font-bold text-primary">{product.name}</h2>
                      <div className="flex items-center gap-2 mt-2">
                        <Zap className="h-4 w-4 text-accent" />
                        <p className="text-sm font-medium text-muted-foreground">{product.specs}</p>
                      </div>
                    </div>
                    <p className="text-sm text-foreground/80">{product.description}</p>
                    <div>
                      <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
                        <Cog size={16} className="text-accent" />
                        Key Applications
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {product.applications.map((app) => (
                          <Badge key={app} variant="secondary">{app}</Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button asChild className="w-full">
                        <Link href="/contact">Request a Quote</Link>
                    </Button>
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
}
