import { getPostBySlug, getBlogPosts } from '@/lib/data';
import { notFound } from 'next/navigation';
import Image from 'next/image';
import { placeholderImages } from '@/lib/placeholder-images';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Calendar, User } from 'lucide-react';

type BlogPostPageProps = {
  params: {
    slug: string;
  };
};

export async function generateStaticParams() {
  const posts = getBlogPosts();
  return posts.map((post) => ({
    slug: post.slug,
  }));
}

export async function generateMetadata({ params }: BlogPostPageProps) {
  const post = getPostBySlug(params.slug);
  if (!post) {
    return { title: 'Post Not Found' };
  }
  return {
    title: `${post.title} | SwitchGear Pro`,
    description: post.excerpt,
  };
}

export default function BlogPostPage({ params }: BlogPostPageProps) {
  const post = getPostBySlug(params.slug);

  if (!post) {
    notFound();
  }

  const postImage = placeholderImages.find((p) => p.id === post.imageId);
  const authorInitial = post.author.split(' ').map(n => n[0]).join('');

  return (
    <div className="bg-secondary">
      <div className="container max-w-4xl mx-auto py-16 md:py-24">
        <article className="bg-background p-8 md:p-12 rounded-lg shadow-lg">
          <header className="mb-8 text-center">
            <h1 className="text-3xl md:text-5xl font-headline font-extrabold text-primary leading-tight">
              {post.title}
            </h1>
            <div className="mt-6 flex justify-center items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <User size={16} />
                <span>{post.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar size={16} />
                <span>{post.date}</span>
              </div>
            </div>
          </header>

          {postImage && (
            <div className="mb-8 rounded-lg overflow-hidden shadow-md">
              <Image
                src={postImage.imageUrl}
                alt={post.title}
                width={1200}
                height={600}
                className="w-full object-cover"
                priority
                data-ai-hint={postImage.imageHint}
              />
            </div>
          )}

          <div className="prose prose-lg dark:prose-invert max-w-none mx-auto">
            <p className="lead">{post.excerpt}</p>
            <p>{post.content}</p>
            
            <h3>Conclusion</h3>
            <p>As technology continues to advance, the role of intelligent and safe switchgear will only become more critical. At SwitchGear Pro, we are committed to staying at the forefront of these innovations, delivering solutions that not only meet today's demands but also anticipate tomorrow's challenges. Contact us to learn more about how our advanced switchgear can benefit your operations.</p>
          </div>
        </article>
      </div>
    </div>
  );
}
