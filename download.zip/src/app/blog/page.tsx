import Image from 'next/image';
import Link from 'next/link';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getBlogPosts } from '@/lib/data';
import { placeholderImages } from '@/lib/placeholder-images';
import { Badge } from '@/components/ui/badge';
import { ArrowRight } from 'lucide-react';

export const metadata = {
  title: 'Blog | SwitchGear Pro',
  description: 'Read the latest industry insights, company news, and technical articles from the experts at SwitchGear Pro.',
};

export default function BlogPage() {
  const posts = getBlogPosts().filter(p => p.status === 'Published');

  return (
    <>
      <section className="bg-primary text-primary-foreground">
        <div className="container py-16 text-center">
          <h1 className="text-4xl md:text-5xl font-headline font-bold">Industry Insights</h1>
          <p className="mt-4 text-lg md:text-xl text-primary-foreground/80 max-w-3xl mx-auto">
            The latest news, technical articles, and updates from the world of power distribution.
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post) => {
              const postImage = placeholderImages.find((p) => p.id === post.imageId);
              return (
                <Card key={post.id} className="flex flex-col overflow-hidden group">
                  <CardHeader className="p-0 border-b">
                    {postImage && (
                      <Link href={`/blog/${post.slug}`} className="block overflow-hidden">
                        <Image
                          src={postImage.imageUrl}
                          alt={post.title}
                          width={600}
                          height={400}
                          className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-300"
                          data-ai-hint={postImage.imageHint}
                        />
                      </Link>
                    )}
                  </CardHeader>
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground">{post.date}</p>
                    <Link href={`/blog/${post.slug}`}>
                      <h2 className="mt-1 text-xl font-headline font-bold text-primary group-hover:underline">{post.title}</h2>
                    </Link>
                    <p className="mt-2 text-sm text-foreground/80 line-clamp-3">{post.excerpt}</p>
                  </CardContent>
                  <CardFooter className="flex-grow flex items-end">
                    <Button asChild variant="outline" className="w-full">
                      <Link href={`/blog/${post.slug}`}>
                        Read More <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        </div>
      </section>
    </>
  );
}
