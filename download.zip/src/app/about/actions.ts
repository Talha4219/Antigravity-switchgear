'use server';

import {
  generateAboutUsContent,
  type GenerateAboutUsInput,
  type GenerateAboutUsOutput,
} from '@/ai/flows/generate-about-us';

type ActionResult = {
  data?: GenerateAboutUsOutput;
  error?: string;
};

export async function generateAboutUsAction(
  input: GenerateAboutUsInput
): Promise<ActionResult> {
  try {
    const output = await generateAboutUsContent(input);
    return { data: output };
  } catch (error) {
    console.error('Error generating content:', error);
    // In a real app, you might want to log this error to a monitoring service
    return { error: 'An unexpected error occurred. Please try again later.' };
  }
}
