import Image from 'next/image';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Award, Users, Target } from 'lucide-react';
import AboutContentGenerator from './components/about-content-generator';
import { placeholderImages } from '@/lib/placeholder-images';

export const metadata = {
  title: 'About Us | SwitchGear Pro',
  description: 'Learn about SwitchGear Pro\'s history, expertise, and commitment to quality and innovation in the power distribution industry.',
};

export default function AboutPage() {
  const teamImage = placeholderImages.find(p => p.id === 'about-team');
  return (
    <>
      <section className="bg-primary text-primary-foreground">
        <div className="container py-16 text-center">
          <h1 className="text-4xl md:text-5xl font-headline font-bold">About SwitchGear Pro</h1>
          <p className="mt-4 text-lg md:text-xl text-primary-foreground/80 max-w-3xl mx-auto">
            Pioneering the future of power distribution with an unwavering commitment to quality, innovation, and our customers.
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid lg:grid-cols-5 gap-12">
            <div className="lg:col-span-3">
              <h2 className="text-3xl font-headline font-semibold text-primary">Our Story</h2>
              <div className="mt-4 space-y-4 text-foreground/80">
                <p>
                  Founded in 1985, SwitchGear Pro began with a simple mission: to build safer and more reliable electrical switchgear. From our humble beginnings in a small workshop, we have grown into an industry leader, known for our engineering excellence and innovative solutions.
                </p>
                <p>
                  Over the decades, we have consistently pushed the boundaries of technology, adapting to the evolving needs of the energy sector. Our journey has been one of continuous improvement, driven by a passion for solving complex challenges and a dedication to powering progress. Today, our products are integral to power grids, industrial complexes, and critical infrastructure across the globe.
                </p>
              </div>
              <div className="mt-12 grid sm:grid-cols-2 gap-8">
                <div className="flex items-start gap-4">
                  <div className="bg-primary text-primary-foreground p-3 rounded-full">
                    <Target size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-headline font-semibold">Our Mission</h3>
                    <p className="mt-1 text-muted-foreground">To provide superior power distribution solutions that ensure safety, reliability, and efficiency for our customers worldwide.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-primary text-primary-foreground p-3 rounded-full">
                    <Users size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-headline font-semibold">Our People</h3>
                    <p className="mt-1 text-muted-foreground">Our team of dedicated engineers, technicians, and professionals are the backbone of our success and innovation.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:col-span-2">
              {teamImage && (
                <Image 
                  src={teamImage.imageUrl}
                  alt="SwitchGear Pro Team"
                  width={500}
                  height={600}
                  className="rounded-lg shadow-lg object-cover w-full h-full"
                  data-ai-hint={teamImage.imageHint}
                />
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-secondary py-16 md:py-24">
        <div className="container">
          <AboutContentGenerator />
        </div>
      </section>

       <section className="py-16 md:py-24">
        <div className="container text-center">
          <h2 className="text-3xl font-headline font-semibold text-primary">Our Core Values</h2>
          <p className="mt-2 text-lg text-muted-foreground max-w-2xl mx-auto">The principles that guide every decision we make.</p>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card>
              <CardHeader>
                <Award className="h-10 w-10 text-primary mx-auto" />
                <CardTitle className="mt-4 font-headline">Quality</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Uncompromising standards in every component we manufacture.</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CheckCircle className="h-10 w-10 text-primary mx-auto" />
                <CardTitle className="mt-4 font-headline">Integrity</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Honesty and transparency in all our business relationships.</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-lightbulb h-10 w-10 text-primary mx-auto"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg>
                <CardTitle className="mt-4 font-headline">Innovation</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Continuously pioneering new technologies and solutions.</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Users className="h-10 w-10 text-primary mx-auto" />
                <CardTitle className="mt-4 font-headline">Customer Focus</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Building lasting partnerships by exceeding expectations.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </>
  );
}
