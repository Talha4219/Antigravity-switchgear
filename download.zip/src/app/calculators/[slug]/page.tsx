import { notFound } from 'next/navigation';
import { calculatorData, type CalculatorInfo } from '@/lib/calculators';
import CalculatorWrapper from '../components/calculator-wrapper';

type CalculatorPageProps = {
  params: {
    slug: string;
  };
};

export async function generateStaticParams() {
  return calculatorData.map((calculator) => ({
    slug: calculator.slug,
  }));
}

export async function generateMetadata({ params }: CalculatorPageProps) {
  const calculator = calculatorData.find((c) => c.slug === params.slug);

  if (!calculator) {
    return { title: 'Calculator Not Found' };
  }

  return {
    title: `${calculator.title} | Evergreen Switchgear`,
    description: `Use our ${calculator.title} to assist with your electrical engineering projects.`,
  };
}

export default function CalculatorPage({ params }: CalculatorPageProps) {
  const calculator = calculatorData.find((c) => c.slug === params.slug);

  if (!calculator) {
    notFound();
  }

  const CalculatorComponent = calculator.component;

  return (
    <CalculatorWrapper
      title={calculator.title}
      description={calculator.description}
      formula={calculator.formula}
    >
      <CalculatorComponent />
    </CalculatorWrapper>
  );
}
