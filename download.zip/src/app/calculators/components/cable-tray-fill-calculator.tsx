'use client';

import { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { PlusCircle, Trash2 } from 'lucide-react';

const cableItemSchema = z.object({
  diameter: z.coerce.number().min(0.1),
  quantity: z.coerce.number().int().min(1),
});

const formSchema = z.object({
  cables: z.array(cableItemSchema),
  trayWidth: z.coerce.number().min(1),
  trayDepth: z.coerce.number().min(1),
  fillPercentage: z.coerce.number().min(1).max(100),
});

export default function CableTrayFillCalculator() {
  const [result, setResult] = useState<number | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cables: [{ diameter: 0.5, quantity: 10 }],
      trayWidth: 12,
      trayDepth: 4,
      fillPercentage: 40,
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "cables"
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { cables, trayWidth, trayDepth, fillPercentage } = values;
    
    const totalCableArea = cables.reduce((acc, cable) => {
      const radius = cable.diameter / 2;
      const area = Math.PI * radius * radius;
      return acc + (area * cable.quantity);
    }, 0);

    const trayArea = trayWidth * trayDepth;
    const maxFillArea = trayArea * (fillPercentage / 100);
    
    const currentFill = (totalCableArea / maxFillArea) * 100;
    setResult(currentFill);
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid sm:grid-cols-3 gap-4">
                 <FormField control={form.control} name="trayWidth" render={({ field }) => (
                    <FormItem><FormLabel>Tray Width (in)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                <FormField control={form.control} name="trayDepth" render={({ field }) => (
                    <FormItem><FormLabel>Tray Depth (in)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                <FormField control={form.control} name="fillPercentage" render={({ field }) => (
                    <FormItem><FormLabel>Max Fill (%)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
            </div>

            <div>
                <h3 className="text-md font-medium mb-2">Cables</h3>
                <div className="space-y-4">
                {fields.map((field, index) => (
                    <div key={field.id} className="grid grid-cols-3 gap-2 items-end p-3 border rounded-md">
                        <FormField control={form.control} name={`cables.${index}.diameter`} render={({ field }) => (
                            <FormItem><FormLabel>Diameter (in)</FormLabel><FormControl><Input type="number" step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                        <FormField control={form.control} name={`cables.${index}.quantity`} render={({ field }) => (
                            <FormItem><FormLabel>Quantity</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                        )} />
                        <Button type="button" variant="destructive" size="sm" onClick={() => remove(index)}>
                            <Trash2 className="h-4 w-4" />
                        </Button>
                    </div>
                ))}
                </div>
                <Button type="button" variant="outline" size="sm" className="mt-4" onClick={() => append({ diameter: 0.5, quantity: 1 })}>
                    <PlusCircle className="mr-2 h-4 w-4" /> Add Cable Type
                </Button>
            </div>

            <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-xl text-primary font-bold mt-2">{result.toFixed(2)}% Full</p>
          <p className="text-sm text-muted-foreground mt-1">Current calculated fill of the cable tray.</p>
        </div>
      )}
    </>
  );
}
