'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const formSchema = z.object({
  load: z.coerce.number().min(1),
  voltage: z.coerce.number().min(1),
  phase: z.enum(['single', 'three']),
  futureGrowth: z.coerce.number().min(0).max(100),
});

const standardKVASizes = [15, 30, 45, 75, 112.5, 150, 225, 300, 500, 750, 1000, 1500, 2000, 2500];

export default function TransformerSizingCalculator() {
  const [result, setResult] = useState<{ required: number, recommended: number } | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      load: 80,
      voltage: 480,
      phase: 'three',
      futureGrowth: 25,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { load, voltage, phase, futureGrowth } = values;
    const phaseMultiplier = phase === 'three' ? Math.sqrt(3) : 1;
    
    const requiredKVA = (load * voltage * phaseMultiplier) / 1000;
    const totalKVA = requiredKVA * (1 + futureGrowth / 100);

    const recommendedKVA = standardKVASizes.find(size => size >= totalKVA) || standardKVASizes[standardKVASizes.length - 1];
    
    setResult({ required: totalKVA, recommended: recommendedKVA });
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-2 gap-4">
            <FormField control={form.control} name="load" render={({ field }) => (
                <FormItem><FormLabel>Total Load (Amps)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="voltage" render={({ field }) => (
                <FormItem><FormLabel>Voltage (V)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="phase" render={({ field }) => (
                <FormItem>
                  <FormLabel>Phase</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select phase" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="single">Single Phase</SelectItem>
                      <SelectItem value="three">Three Phase</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
            <FormField control={form.control} name="futureGrowth" render={({ field }) => (
                <FormItem><FormLabel>Future Growth (%)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
          </div>
          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-sm text-muted-foreground mt-2">Required kVA (including growth): {result.required.toFixed(2)} kVA</p>
          <p className="text-xl text-primary font-bold mt-1">Recommended Standard Size: {result.recommended} kVA</p>
        </div>
      )}
    </>
  );
}
