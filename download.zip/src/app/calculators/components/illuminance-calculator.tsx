'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const formSchema = z.object({
  lumens: z.coerce.number().min(1),
  area: z.coerce.number().min(1),
  cu: z.coerce.number().min(0.1).max(1), // Coefficient of Utilization
  llf: z.coerce.number().min(0.1).max(1), // Light Loss Factor
});

export default function IlluminanceCalculator() {
  const [result, setResult] = useState<number | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      lumens: 5000, // per luminaire
      area: 200, // sq. feet
      cu: 0.7,
      llf: 0.8,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { lumens, area, cu, llf } = values;
    
    const illuminance = (lumens * cu * llf) / area;
    
    setResult(illuminance);
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-2 gap-4">
            <FormField control={form.control} name="lumens" render={({ field }) => (
                <FormItem><FormLabel>Total Lumens</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="area" render={({ field }) => (
                <FormItem><FormLabel>Area (sq. ft. or m²)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="cu" render={({ field }) => (
                <FormItem><FormLabel>Coefficient of Utilization</FormLabel><FormControl><Input type="number" step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="llf" render={({ field }) => (
                <FormItem><FormLabel>Light Loss Factor</FormLabel><FormControl><Input type="number" step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
          </div>
          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-xl text-primary font-bold mt-2">{result.toFixed(2)} lx or fc</p>
          <p className="text-sm text-muted-foreground mt-1">Average maintained illuminance. Assumes area unit matches desired output unit (e.g., m² for lux, ft² for foot-candles).</p>
        </div>
      )}
    </>
  );
}
