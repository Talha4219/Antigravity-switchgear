'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const formSchema = z.object({
  batteryCapacity: z.coerce.number().min(1), // in Amp-hours (Ah)
  batteryVoltage: z.coerce.number().min(1), // in Volts (V)
  loadPower: z.coerce.number().min(1), // in Watts (W)
  efficiency: z.coerce.number().min(1).max(100), // in %
});

export default function EmergencyLightingRunTimeCalculator() {
  const [result, setResult] = useState<number | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      batteryCapacity: 10,
      batteryVoltage: 12,
      loadPower: 50,
      efficiency: 85,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { batteryCapacity, batteryVoltage, loadPower, efficiency } = values;
    
    const batteryEnergy = batteryCapacity * batteryVoltage;
    const effectivePowerDraw = loadPower / (efficiency / 100);
    const runTime = batteryEnergy / effectivePowerDraw;
    
    setResult(runTime);
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-2 gap-4">
            <FormField control={form.control} name="batteryCapacity" render={({ field }) => (
                <FormItem><FormLabel>Battery Capacity (Ah)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="batteryVoltage" render={({ field }) => (
                <FormItem><FormLabel>Battery Voltage (V)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="loadPower" render={({ field }) => (
                <FormItem><FormLabel>Total Load (W)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="efficiency" render={({ field }) => (
                <FormItem><FormLabel>Inverter Efficiency (%)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
          </div>
          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-xl text-primary font-bold mt-2">{result.toFixed(2)} Hours</p>
          <p className="text-sm text-muted-foreground mt-1">Estimated run time of the emergency lighting system.</p>
        </div>
      )}
    </>
  );
}
