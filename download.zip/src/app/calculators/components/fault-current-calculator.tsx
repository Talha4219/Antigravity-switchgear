'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const formSchema = z.object({
  voltage: z.coerce.number().min(1, "Voltage must be greater than 0"),
  kVA: z.coerce.number().min(1, "kVA must be greater than 0"),
  impedance: z.coerce.number().min(0.1, "Impedance must be greater than 0"),
});

export default function FaultCurrentCalculator() {
  const [result, setResult] = useState<number | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      voltage: 480,
      kVA: 1500,
      impedance: 5.75,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { voltage, kVA, impedance } = values;
    const faultCurrent = (kVA * 1000) / (voltage * Math.sqrt(3)) / (impedance / 100);
    setResult(faultCurrent);
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid sm:grid-cols-3 gap-4">
            <FormField
              control={form.control}
              name="voltage"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>System Voltage (V)</FormLabel>
                  <FormControl>
                    <Input type="number" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="kVA"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Transformer kVA</FormLabel>
                  <FormControl>
                    <Input type="number" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="impedance"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Transformer Impedance (%)</FormLabel>
                  <FormControl>
                    <Input type="number" step="0.01" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-xl text-primary font-bold mt-2">{result.toFixed(2)} Amps</p>
          <p className="text-sm text-muted-foreground mt-1">Symmetrical short-circuit current.</p>
        </div>
      )}
    </>
  );
}
