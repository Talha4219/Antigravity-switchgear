'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const formSchema = z.object({
  panelRating: z.coerce.number().min(1), // in Watts
  numberOfPanels: z.coerce.number().int().min(1),
  sunHours: z.coerce.number().min(0.1).max(24), // Peak sun hours per day
  performanceRatio: z.coerce.number().min(0.1).max(1), // System losses
});

export default function SolarPanelOutputCalculator() {
  const [result, setResult] = useState<{ daily: number, monthly: number, yearly: number } | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      panelRating: 400,
      numberOfPanels: 10,
      sunHours: 5,
      performanceRatio: 0.75, // Accounts for inverter, dirt, shading, etc.
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { panelRating, numberOfPanels, sunHours, performanceRatio } = values;
    
    const totalPowerKW = (panelRating * numberOfPanels) / 1000;
    const dailyEnergy = totalPowerKW * sunHours * performanceRatio;
    
    setResult({
      daily: dailyEnergy,
      monthly: dailyEnergy * 30,
      yearly: dailyEnergy * 365,
    });
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-2 gap-4">
            <FormField control={form.control} name="panelRating" render={({ field }) => (
                <FormItem><FormLabel>Panel Rating (W)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="numberOfPanels" render={({ field }) => (
                <FormItem><FormLabel>Number of Panels</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="sunHours" render={({ field }) => (
                <FormItem><FormLabel>Peak Sun Hours/Day</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="performanceRatio" render={({ field }) => (
                <FormItem><FormLabel>Performance Ratio</FormLabel><FormControl><Input type="number" step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
          </div>
          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center mt-2">
            <div>
              <p className="text-xl font-bold text-primary">{result.daily.toFixed(2)}</p>
              <p className="text-sm text-muted-foreground">kWh / Day</p>
            </div>
            <div>
              <p className="text-xl font-bold text-primary">{result.monthly.toFixed(2)}</p>
              <p className="text-sm text-muted-foreground">kWh / Month</p>
            </div>
            <div>
              <p className="text-xl font-bold text-primary">{result.yearly.toFixed(2)}</p>
              <p className="text-sm text-muted-foreground">kWh / Year</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
