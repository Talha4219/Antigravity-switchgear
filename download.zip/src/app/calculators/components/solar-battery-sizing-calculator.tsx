'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const formSchema = z.object({
  dailyConsumption: z.coerce.number().min(1), // in kWh
  autonomyDays: z.coerce.number().min(0.5), // Days of backup
  batteryVoltage: z.coerce.number().min(1),
  depthOfDischarge: z.coerce.number().min(10).max(100), // DoD in %
});

export default function SolarBatterySizingCalculator() {
  const [result, setResult] = useState<{ kWh: number, Ah: number } | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      dailyConsumption: 15,
      autonomyDays: 2,
      batteryVoltage: 48,
      depthOfDischarge: 80,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { dailyConsumption, autonomyDays, batteryVoltage, depthOfDischarge } = values;
    
    const totalEnergy = dailyConsumption * autonomyDays;
    const requiredKWh = totalEnergy / (depthOfDischarge / 100);
    const requiredAh = (requiredKWh * 1000) / batteryVoltage;
    
    setResult({ kWh: requiredKWh, Ah: requiredAh });
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-2 gap-4">
            <FormField control={form.control} name="dailyConsumption" render={({ field }) => (
                <FormItem><FormLabel>Daily Use (kWh)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="autonomyDays" render={({ field }) => (
                <FormItem><FormLabel>Days of Autonomy</FormLabel><FormControl><Input type="number" step="0.5" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="batteryVoltage" render={({ field }) => (
                <FormItem><FormLabel>Battery Voltage (V)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="depthOfDischarge" render={({ field }) => (
                <FormItem><FormLabel>Depth of Discharge (%)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
          </div>
          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-xl text-primary font-bold mt-2">{result.kWh.toFixed(2)} kWh / {result.Ah.toFixed(2)} Ah</p>
          <p className="text-sm text-muted-foreground mt-1">Required total battery capacity at {form.getValues('batteryVoltage')}V.</p>
        </div>
      )}
    </>
  );
}
