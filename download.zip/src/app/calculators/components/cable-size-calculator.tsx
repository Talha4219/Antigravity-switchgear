'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const formSchema = z.object({
    current: z.coerce.number().min(1),
    length: z.coerce.number().min(1),
    voltage: z.coerce.number().min(1),
    phase: z.enum(['single', 'three']),
    conductor: z.enum(['copper', 'aluminum']),
    voltageDrop: z.coerce.number().min(0.1).max(10),
});

const K_VALUES = {
    copper: 12.9,
    aluminum: 21.2,
};
const AWG_SIZES = [14, 12, 10, 8, 6, 4, 3, 2, 1, 0, 0, 0, 0, 250, 300, 350, 400, 500];
const awgToCM = (awg: number) => 10**( (50-awg)/10 ) * 100; // simplified

export default function CableSizeCalculator() {
  const [result, setResult] = useState<number | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      current: 80,
      length: 200,
      voltage: 480,
      phase: 'three',
      conductor: 'copper',
      voltageDrop: 3,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { current, length, voltage, phase, conductor, voltageDrop } = values;
    
    const maxVD = voltage * (voltageDrop / 100);
    const K = K_VALUES[conductor];
    const phaseMultiplier = phase === 'three' ? Math.sqrt(3) : 2;

    const requiredCM = (phaseMultiplier * K * current * length) / maxVD;

    // This is a simplification. Real world requires ampacity tables.
    const requiredAWG = 50 - 10 * Math.log10(requiredCM / 100);
    const standardAWG = AWG_SIZES.reverse().find(size => size <= requiredAWG) || AWG_SIZES[0];
    AWG_SIZES.reverse();
    
    setResult(Math.round(requiredAWG));
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <FormField control={form.control} name="current" render={({ field }) => (
                <FormItem><FormLabel>Current (A)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="length" render={({ field }) => (
                <FormItem><FormLabel>Length (feet)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="voltage" render={({ field }) => (
                <FormItem><FormLabel>Voltage (V)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="phase" render={({ field }) => (
                <FormItem><FormLabel>Phase</FormLabel><Select onValueChange={field.onChange} defaultValue={field.value}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl><SelectContent><SelectItem value="single">Single Phase</SelectItem><SelectItem value="three">Three Phase</SelectItem></SelectContent></Select><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="conductor" render={({ field }) => (
                <FormItem><FormLabel>Conductor</FormLabel><Select onValueChange={field.onChange} defaultValue={field.value}><FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl><SelectContent><SelectItem value="copper">Copper</SelectItem><SelectItem value="aluminum">Aluminum</SelectItem></SelectContent></Select><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="voltageDrop" render={({ field }) => (
                <FormItem><FormLabel>Max Voltage Drop (%)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
          </div>
          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-xl text-primary font-bold mt-2">AWG {result} or larger</p>
          <p className="text-sm text-muted-foreground mt-1">This is an estimate based on voltage drop only. Always consult NEC/local codes for ampacity and other requirements.</p>
        </div>
      )}
    </>
  );
}
