'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const formSchema = z.object({
  phase: z.enum(['single', 'three']),
  voltage: z.coerce.number().min(1),
  current: z.coerce.number().min(0.1),
  length: z.coerce.number().min(1),
  wireSize: z.coerce.number().min(0.1),
  conductor: z.enum(['copper', 'aluminum']),
});

const K_VALUES = {
  copper: 12.9, // for stranded copper
  aluminum: 21.2, // for stranded aluminum
};

export default function VoltageDropCalculator() {
  const [result, setResult] = useState<{ drop: number, percentage: number } | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      phase: 'three',
      voltage: 480,
      current: 100,
      length: 150,
      wireSize: 4, // AWG
      conductor: 'copper',
    },
  });

  const awgToCM = (awg: number) => 10**( (50-awg)/10 ) * 100;

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { phase, voltage, current, length, wireSize, conductor } = values;
    
    const K = K_VALUES[conductor];
    const L = length;
    const I = current;
    const CM = awgToCM(wireSize);

    const phaseMultiplier = phase === 'three' ? Math.sqrt(3) : 2;

    const voltageDrop = (phaseMultiplier * K * I * L) / CM;
    const voltageDropPercentage = (voltageDrop / voltage) * 100;
    
    setResult({ drop: voltageDrop, percentage: voltageDropPercentage });
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <FormField control={form.control} name="phase" render={({ field }) => (
                <FormItem>
                  <FormLabel>Phase</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select phase" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="single">Single Phase</SelectItem>
                      <SelectItem value="three">Three Phase</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
            <FormField control={form.control} name="voltage" render={({ field }) => (
                <FormItem><FormLabel>Voltage (V)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="current" render={({ field }) => (
                <FormItem><FormLabel>Current (A)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="length" render={({ field }) => (
                <FormItem><FormLabel>Cable Length (feet)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="wireSize" render={({ field }) => (
                <FormItem><FormLabel>Wire Size (AWG)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="conductor" render={({ field }) => (
                <FormItem>
                  <FormLabel>Conductor</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select material" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="copper">Copper</SelectItem>
                      <SelectItem value="aluminum">Aluminum</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
          </div>
          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-xl text-primary font-bold mt-2">{result.drop.toFixed(2)} V ({result.percentage.toFixed(2)}%)</p>
          <p className="text-sm text-muted-foreground mt-1">This is the estimated voltage drop over the specified distance.</p>
        </div>
      )}
    </>
  );
}
