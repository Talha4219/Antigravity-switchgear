'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const formSchema = z.object({
  power: z.coerce.number().min(1),
  currentPF: z.coerce.number().min(0.1).max(1),
  targetPF: z.coerce.number().min(0.1).max(1),
});

export default function PowerFactorCorrectionCalculator() {
  const [result, setResult] = useState<number | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      power: 100, // in kW
      currentPF: 0.8,
      targetPF: 0.95,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { power, currentPF, targetPF } = values;

    if (currentPF >= targetPF) {
        setResult(0);
        return;
    }

    const angle1 = Math.acos(currentPF);
    const angle2 = Math.acos(targetPF);

    const requiredKVAR = power * (Math.tan(angle1) - Math.tan(angle2));
    
    setResult(requiredKVAR);
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid sm:grid-cols-3 gap-4">
            <FormField control={form.control} name="power" render={({ field }) => (
                <FormItem><FormLabel>Real Power (kW)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="currentPF" render={({ field }) => (
                <FormItem><FormLabel>Current Power Factor</FormLabel><FormControl><Input type="number" step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="targetPF" render={({ field }) => (
                <FormItem><FormLabel>Target Power Factor</FormLabel><FormControl><Input type="number" step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
          </div>
          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-xl text-primary font-bold mt-2">{result.toFixed(2)} kVAR</p>
          <p className="text-sm text-muted-foreground mt-1">Required capacitor bank size to achieve the target power factor.</p>
        </div>
      )}
    </>
  );
}
