'use client';

import { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PlusCircle, Trash2 } from 'lucide-react';

const loadItemSchema = z.object({
  name: z.string().min(1, "Name is required"),
  quantity: z.coerce.number().int().min(1),
  power: z.coerce.number().min(1),
  powerFactor: z.coerce.number().min(0.1).max(1),
});

const formSchema = z.object({
  loads: z.array(loadItemSchema),
  voltage: z.coerce.number().min(1),
  phase: z.enum(['single', 'three']),
});

export default function LoadCalculator() {
  const [result, setResult] = useState<number | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      loads: [{ name: 'Motor', quantity: 1, power: 7500, powerFactor: 0.85 }],
      voltage: 480,
      phase: 'three',
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "loads"
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const { loads, voltage, phase } = values;
    const phaseMultiplier = phase === 'three' ? Math.sqrt(3) : 1;

    const totalVA = loads.reduce((acc, load) => {
      return acc + (load.quantity * load.power) / load.powerFactor;
    }, 0);

    const totalCurrent = totalVA / (voltage * phaseMultiplier);
    setResult(totalCurrent);
  }

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid sm:grid-cols-2 gap-4">
            <FormField control={form.control} name="voltage" render={({ field }) => (
                <FormItem><FormLabel>Voltage (V)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            <FormField control={form.control} name="phase" render={({ field }) => (
                <FormItem>
                  <FormLabel>Phase</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl><SelectTrigger><SelectValue placeholder="Select phase" /></SelectTrigger></FormControl>
                    <SelectContent>
                      <SelectItem value="single">Single Phase</SelectItem>
                      <SelectItem value="three">Three Phase</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
          </div>

          <div>
            <h3 className="text-md font-medium mb-2">Loads</h3>
            <div className="space-y-4">
              {fields.map((field, index) => (
                <div key={field.id} className="grid grid-cols-1 sm:grid-cols-5 gap-2 items-end p-3 border rounded-md relative">
                   <FormField control={form.control} name={`loads.${index}.name`} render={({ field }) => (
                     <FormItem className="col-span-1 sm:col-span-2"><FormLabel>Load Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name={`loads.${index}.quantity`} render={({ field }) => (
                      <FormItem><FormLabel>Qty</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name={`loads.${index}.power`} render={({ field }) => (
                      <FormItem><FormLabel>Power (W)</FormLabel><FormControl><Input type="number" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name={`loads.${index}.powerFactor`} render={({ field }) => (
                      <FormItem><FormLabel>PF</FormLabel><FormControl><Input type="number" step="0.01" {...field} /></FormControl><FormMessage /></FormItem>
                    )} />
                  <Button type="button" variant="ghost" size="icon" className="absolute top-1 right-1 sm:hidden" onClick={() => remove(index)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                  <Button type="button" variant="destructive" size="sm" className="hidden sm:flex" onClick={() => remove(index)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
            <Button type="button" variant="outline" size="sm" className="mt-4" onClick={() => append({ name: '', quantity: 1, power: 1000, powerFactor: 0.9 })}>
              <PlusCircle className="mr-2 h-4 w-4" /> Add Load
            </Button>
          </div>

          <Button type="submit">Calculate</Button>
        </form>
      </Form>
      {result !== null && (
        <div className="mt-6">
          <h3 className="font-semibold text-lg">Result</h3>
          <p className="text-xl text-primary font-bold mt-2">{result.toFixed(2)} Amps</p>
          <p className="text-sm text-muted-foreground mt-1">Total calculated current demand.</p>
        </div>
      )}
    </>
  );
}
