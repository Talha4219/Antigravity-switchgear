import Link from 'next/link';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { calculatorData } from '@/lib/calculators';

export const metadata = {
  title: 'Calculators | Evergreen Switchgear',
  description: 'A suite of powerful electrical calculators to assist with your engineering projects, from fault current to solar panel sizing.',
};

export default function CalculatorsPage() {
  return (
    <>
      <section className="bg-primary text-primary-foreground">
        <div className="container py-16 text-center">
          <h1 className="text-4xl md:text-5xl font-headline font-bold">Electrical Calculators</h1>
          <p className="mt-4 text-lg md:text-xl text-primary-foreground/80 max-w-3xl mx-auto">
            A suite of powerful tools to assist with your electrical engineering projects. Select a calculator below to get started.
          </p>
        </div>
      </section>

      <section className="py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {calculatorData.map((calculator) => (
              <Link href={`/calculators/${calculator.slug}`} key={calculator.slug} className="group">
                <Card className="h-full hover:shadow-lg transition-shadow duration-300 flex flex-col">
                  <CardHeader className="flex-row items-center gap-4 space-y-0">
                     <div className="bg-primary/10 p-3 rounded-md">
                        <calculator.icon className="h-6 w-6 text-primary" />
                     </div>
                     <div>
                        <CardTitle className="font-headline text-lg group-hover:text-primary">{calculator.title}</CardTitle>
                     </div>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <CardDescription>{calculator.description}</CardDescription>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
