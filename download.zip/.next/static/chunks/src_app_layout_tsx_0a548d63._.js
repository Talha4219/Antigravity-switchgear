(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__0084cd6b._.css",
  "static/chunks/src_1bb5de91._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_d45abfbb._.js",
  "static/chunks/94568_@firebase_auth_dist_esm2017_39867e80._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_d9c36ae7.js",
  "static/chunks/node_modules_@radix-ui_1f591085._.js",
  "static/chunks/node_modules_@floating-ui_1b6e7b6d._.js",
  "static/chunks/node_modules_@firebase_e28afb61._.js",
  "static/chunks/node_modules_8a61687e._.js"
],
    source: "dynamic"
});
